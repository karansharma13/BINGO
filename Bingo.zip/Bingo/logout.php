<?php 

include 'connectDB.php';
session_start();

$id = $_SESSION["uid"];

$act=$conn->query("update user set is_available='0' where uid = '$id' ");
$conn->query("delete from matches where p1=$id or p2=$id");
// $conn->query("");

if($act)
	header("location:login.php");


session_destroy();

$conn->close();

 ?>