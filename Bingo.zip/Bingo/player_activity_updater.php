<?php 

	session_start();
	include 'connectDB.php';

	$id = $_SESSION["uid"];
	$gameid = $_GET["game"];

	 date_default_timezone_set("Asia/Calcutta"); 
	 // $acres=$conn->query("select * from user where uid = '$id'");
	 // $acrow=$acres->fetch_object();
	 // $check=$acrow->last_act;
	 $date = date( 'Y-m-d H:i:s');
	 $res =$conn->query("update user set last_act='$date', is_available='1' where uid = '$id'"); 
	 $res =$conn->query("update game set last_act_game='$date' where gid = '$gameid'"); 
	 // $diff = strtotime($date) - strtotime($check);

	 $conn->close();
 ?>