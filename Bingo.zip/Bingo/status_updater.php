<?php 

session_start();
include 'connectDB.php';

$player1 = $_POST["player"];
$status = $_POST["status"];
$gameid = $_POST["game"];

if($status=="ready")
{
	if($_SESSION["uid"]!=$player1)
	{
		$q="update game set p2status='ready' where gameid = '$gameid'";
		$res =$conn->query($q);
	}
	else
	{
		$q="update game set p1status='ready' where gameid = '$gameid'";
		$res =$conn->query($q);
	}
}
if($status=="isready")
{
	if($_SESSION["uid"]!=$player1)
	{
		$q="select p1status from game where gameid = '$gameid'";
		$res =$conn->query($q);
		$row=$res->fetch_object();
		echo "$row->p1status";
	}
	else
	{
		$q="select p2status from game where gameid = '$gameid'";
		$res =$conn->query($q);
		$row=$res->fetch_object();
		echo "$row->p2status";
	}
}
if($status=="amWinner")
{
	if($_SESSION["uid"]!=$player1)
	{
		$q="update game set p2status='winner' where gameid = '$gameid'";
		$res =$conn->query($q);
	}
	else
	{
		$q="update game set p1status='winner' where gameid = '$gameid'";
		$res =$conn->query($q);
	}
}
$conn->close();

 ?>