<?php 

session_start();
include 'connectDB.php';

$p1=$_GET['player1'];
$p2=$_SESSION["uid"];

$gid=mt_rand(1000000,1000000000);

date_default_timezone_set("Asia/Calcutta");
$date = date( 'Y-m-d H:i:s');

$res = $conn->query("insert into game (player1id,player2id,gameid,last_act_game,turn) values ('$p1','$p2','$gid','$date','p1')");

if($res)
	header("location:main.php?game=$gid&player1=$p1&player2=$p2");

$conn->close();
 ?>