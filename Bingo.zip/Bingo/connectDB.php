<?php 

	$conn= new mysqli("localhost","root","","bingo");

 ?>