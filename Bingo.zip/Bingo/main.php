<?php 
session_start();
include 'connectDB.php';

$id=$_SESSION['uid'];

$p1=$_GET["player1"];
$p2=$_GET["player2"];
$game=$_GET["game"];

echo "<script>const p1 = $p1; const p2 = $p2; const game = $game;</script>";

$q="update user set is_available='0' where uid='$p1' or uid='$p2'";
$conn->query($q);

if($_SESSION["uid"]!=$p1)
{
	 [$p1, $p2] = [$p2, $p1];
	 echo "<script>const Mp1 = $p1; const Mp2 = $p2; </script>";
}
else
	echo "<script>const Mp1 = $p1; const Mp2 = $p2; </script>";

$res=$conn->query("select ufname,ulname from user where uid = '$p2'");
$row=$res->fetch_object();
echo "<script>var player1name = 'You';var player2name = '$row->ufname'; </script>";
?>
<!DOCTYPE html>
<html>
<head>
	<title>JS</title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Radio+Canada&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<center>
	<!-- <img src="imgs/win.gif" id="winimg"> -->
	<div class="container">
		<div class="upper">
				<div id="status">Player 2 Status: <span id="stat">Not Ready</span></div>
				<div id="logout">
					<a href="players.php?player1=<?php echo $_SESSION["uid"]; ?>">All Players</a>
					<a href="logout.php">Logout</a>
				</div>
		</div>
		<div class="lower">
			<div class="bingside" >
			<div class="bingo">
				<h1 id="bh1">Bingo!</h1>

				<div id="cnt" >	
				</div>
			</div>
			</div>
			<div id="menu" class="menu">
				<h1 id="player">You <span id="vs">vs</span><?php echo " $row->ufname $row->ulname"; ?></h1>
				<div class="settings">

					<div id="auto_manu">
							<button id="auto">Auto fill</button>

							<button id="manu">Manual fill</button>
					</div>

					<div id="bings">
						Bings: <span id="bngs">0</span>
					</div>
					<div id="won"></div>
					<div class="doRematch">
						<a href="players.php?player1=<?php echo $id; ?>" class="rmatch">Go to Players</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	
</center>

<script src="js/jquery-3.6.0.min.js"></script>

<script type="text/javascript" src="js/source.js"></script>
</body>
</html>
<?php $conn->close(); ?>