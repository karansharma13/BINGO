<?php 
session_start();
include 'cleanup.php';
include 'connectDB.php';

$id=$_SESSION["uid"];
$conn->query("update user set is_available='1' where uid = '$id'");
$conn->query("delete from game where player1id=$id");

$conn->close();
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Players Availabel</title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Radio+Canada&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/players_css.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>

	<div class="logout"><a href="logout.php" id="logout">Logout</a></div>
<center>
	<div class="wantToPlay">Hello</div>
	<h1>Players Available</h1>
	<div class="container" >
		<table id="load-table">
		<!-- <tr><td class="players">Vyas Aditya</td><td><a href="#">Play</a></td></tr>
		<tr><td class="players">Gunajn Vyas</td><td><a href="#" class="nAvail">Play</a></td></tr> -->
		</table>
	</div>
	<div class="data"></div>
</center>

<script src="js/jquery-3.6.0.min.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		load_data();
		var interval;
		var p1;
		var p2;
	//get player 1 param from url
		var param1 = new URLSearchParams(window.location.search);
		play1 = param1.get("player1");

	//handling play link event
		$(document).on("click",".play",function(e){
			e.preventDefault();//clicked button
			var t= $(this);
			stopint();

			//get players' Ids
			var linkText = $(this).attr("href");
			var link = new URL("http://"+linkText);
			// p1 = link.searchParams.get("player1");
			p2 = link.searchParams.get("player2");


			$.ajax({
				url: "matching_player.php",
				type: "POST",
				data: {player1 : play1, player2 : p2},
				success: function(data){
					t.text("Confirming...")
					setTimeout(function(){
						$.ajax({
							url: "match_request_cleanup.php?player1=play1&clean=1",
							type: "GET",
							success:function(data){
								t.text("Play");
								t.attr("href",linkText);
								startint();
							}
						})		
					},5000)
				}
			});
		});
		startint();
	});

//list of online

	function load_data(){
		$.ajax({
			url:"online_players.php",
			type: "POST",
			success: function(data){
				$("#load-table").html(data);							
				// $(".data").text(data);							
			}	
		});		
	}

// List of people who wants to play with you

	function wantToPlay()
	{
		$.ajax({
				url: "match_request.php",
				type: "GET",
				success: function(data){
					// $(".wantToPlay").html(data);
					if(data!="no_player")
					{
						$(".wantToPlay").html(data);
						$(".wantToPlay").css("display","block");
					}
					else
					{
						$(".wantToPlay").html("");
						$(".wantToPlay").css("display","none");
					}	
					// console.log(data);
				}
			});
	} 


//check if you are enlisted in game table with game id
	function anInGame()
	{

		$.ajax({
			url: "amInGame.php",
			type: "GET",
			success: function(data){
				if(data!=""){
					var result = JSON.parse(data);
					window.location ="main.php?game="+result[0]+"&player1="+result[1]+"&player2="+result[2];
				}
			}
		}); 

	}

//activity updater

	function actUpdate()
	{
		$.ajax({
			url: "player_activity_updater.php",
			type: "GET",
			success: function(){
			}
		});	
	}

//Interval start/stop funcs
	function startint()
	{
		interval = setInterval(function(){
			load_data();
			wantToPlay();
			anInGame();
			actUpdate();
		},3000);
	}
	function stopint()
	{
		clearInterval(interval);	
	}
</script>
</body>
</html>