<?php 
session_start();
include 'connectDB.php';

$p1=$_GET["player1"];
$p2=$_SESSION["uid"];

if(isset($_GET["game"]))
{
	$res=$conn->query("delete from matches where p2='$p2'");
	header("location:pregame_setup.php?player1=$p1&player2=$p2");	
}
if(isset($_GET["clean"]))
{
	$res=$conn->query("delete from matches where p1='$p2'");
}
if(isset($_GET["cancel"]))
{
	$res=$conn->query("delete from matches where p1='$p1'");
	header("location:players.php?player1=$p2");	
}
$conn->close();

 ?>