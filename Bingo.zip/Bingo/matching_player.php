<?php 

//insert record in matches table to confirm game

session_start();
include 'connectDB.php';

$p1 = $_POST["player1"];
$p2 = $_POST["player2"];

$res=$conn->query("insert into matches (p1,p2) values ('$p1',$p2)");


$conn->close();
 ?>