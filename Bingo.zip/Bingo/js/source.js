// ****************************************************jquery*********************************************************************

$(document).ready(function(){

		// var param1 = new URLSearchParams(window.location.search);
		// play = param1.get("player1");
		var lmove;

		//buttons click events
		$(document).on("click",".btn",function() {
			if(gameIsComplete){
				alert("Stop clicking you fooll");
			}
			if(isBoardComplete && isMyTurn &&!(gameIsComplete))
			{

					$(this).css({"background-color" : "salmon","text-decoration" : "line-through"});
					lmove = $(this).text();
					postMove(lmove);
					isMyTurn = false;
					var bingIndex = parseInt(this.id.slice(3,5));
					bing[bingIndex-1]=1;
					if(isBing(bing)['bind'])
					{	
						amWinner();
						winner("You");
						// $("#won").text("You won!");
						// $("#won").css("display","block");
						// $(".doRematch").css("display","block");
						// gameIsComplete = true;
					}
					$("#bngs").text(isBing(bing)['bings']);
					
			}
			// console.log(isBoardComplete);
		});



		$("#auto").on("click",function(){
			autoBoard();
			amReady();
			$("#auto_manu").remove();
		});
		$("#manu").on("click",function(){
			autoBoard();
			manuBoard();
			$("#auto_manu").remove();
		});

		setInterval(function()
		{
			getMove();
		},2000);
		setInterval(function()
		{
			actupdater();
		},60000);

		isReadyint = setInterval(isReady,2000);
		
});

	function actupdater()
	{
		$.ajax({
			url: "game_activity_updater.php",
			type: "POST",
			data: {player : p1, game: game},
			success: function(data){
				if(data=="left")
					$("#stat").text("left");	
			}
		})
	}
	function amReady()
	{
		$.ajax({
			url: "status_updater.php",
			type: "POST",
			data: {player : p1, status: "ready",game: game},
			success: function(data){
				console.log(data);
			}
		})	
	}
	function isReady()
	{
		$.ajax({
			url: "status_updater.php",
			type: "POST",
			data: {player : p1, status: "isready",game: game},
			success: function(data){
				if(data=="ready")
				{
					clearInterval(isReadyint);
					$(".bingo").css("background-color","white");
					$("#stat").text("playing");
				}
				
			}
		})	
	}
	function amWinner()
	{
		$.ajax({
			url: "status_updater.php",
			type: "POST",
			data: {player : p1, status: "amWinner",game: game},
			success: function(data){
				console.log(data);
			}
		})	
	}
	function postMove(move)
	{
		$.ajax({
			url: "moves.php",
			type: "POST",
			data: {postmove: move,game: game, turn: Mp2},
			success: function(data){
			// 	var move = parseInt(data);
			// 	var id = mapper[move+1];
			// 	$("btn"+id).click();
				// console.log(Mp2);
			}	
		})
	}
	function getMove()
	{
		$.ajax({
			url: "moves.php",
			type: "POST",
			data: {player : p1,getmove: "true",game: game},
			success: function(data){
				// console.log(data)
				var res = JSON.parse(data);
				var move = parseInt(res[0]);
				var id = mapper[move-1];

				if(res[2]=="winner")
					winner(player2name);

				bing[id-1]=1;
				$("#btn"+id).css({"background-color" : "salmon","text-decoration" : "line-through"});
				if(res[1]==Mp1)
					isMyTurn=true;

				console.log(isMyTurn)
			}	
		})
	}
	function winner(str)
	{
		$("#won").text(str+" won!");
		$("#won").css("display","block");
		$(".doRematch").css("display","block");
		gameIsComplete = true;
	}

// ****************************************************Js*********************************************************************

// Create array of 25 nu ms
var arr = [];
var Numbers=25;
var isBoardComplete = false;
var gameIsComplete = false;
var isReadyint;
var isMyTurn;
if(Mp1==p1)
	isMyTurn = true;
else
	isMyTurn = false;
	
//create array of binged buttons
var bing = new Array(25).fill(0);
var mapper = new Array(25).fill(0);

//adding 25 buttons dynamically	
	// document.getElementById('par').style.border ="solid 1px black";
	function autoBoard(){

		//Shuffle array
		for (let i = 1; i <= Numbers; i++) {
		arr.push(i);
		}
		shuffle(arr);

		var box = document.getElementById('cnt');
		var count =0;
		for (var i = 0; i < 5; i++) {

		var newCol = document.createElement("div");
		newCol.setAttribute("class","fbox");
		box.appendChild(newCol);

		for (var j = 0; j < 5; j++) {

			var fbox = document.getElementsByClassName("fbox");

			var btn = document.createElement("button");
			btn.setAttribute("class","btn");
			btn.setAttribute("id","btn"+(count+1));
			btn.innerText=arr[count];
			mapper[arr[count]-1]=count+1;
			fbox[i].appendChild(btn);
			count++;
		}

		}
		isBoardComplete=true;
	}

	//Manuallaly fill board
	function manuBoard(){
		isBoardComplete=false;
		var nums=1;
		$(".btn").text("");
		$(".btn").click(function(){
			if(nums<=25 && $(this).text()=="")
			{
				$(this).text(nums);
				mapper[nums-1]=parseInt(this.id.slice(3,5));

				if(nums>25)
				{
					isBoardComplete = true;
				}
				if(nums==25)
				{
					amReady();
				}
				nums++;
			}
			
		});	
		
	}
			
			
// function for shuffling array nums
	function shuffle(array) {
	  let currentIndex = array.length,  randomIndex;

	  // While there remain elements to shuffle.
	  while (currentIndex != 0) {

	    // Pick a remaining element.
	    randomIndex = Math.floor(Math.random() * currentIndex);
	    currentIndex--;

	    // And swap it with the current element.
	    [array[currentIndex], array[randomIndex]] = [
	      array[randomIndex], array[currentIndex]];
	  }

	  return array;
	}

//function to handle button click event 
	// function onclicked(){
			
	// 	// let btnn = document.getElementsByClassName("btn");
	// 	this.style.backgroundColor = "salmon";
	// 	this.style.textDecoration = "line-through";
	// 	// this.style.backgroundColor = "#cd5700";
	// 	var bingIndex = parseInt(this.id.slice(3,5));
	// 	bing[bingIndex-1]=1;

	// 	if(isBing(bing))
	// 	{
	// 		document.getElementById('won').innerText="Winner!";	
	// 	}
	// 	// console.log(isHorzBing(bing));
	// 	// console.log(isDiagBing(bing));
	// 	// console.log(isVertBing(bing));
	// 	// console.log(bing);
	// }

function isVertBing(arr) {

	var vertBinged=0;
	for (var i = 0; i < 5; i++) {
		var flag = true;
		for (var j = i; j < 25; j+=5) {
			if(arr[j]==0)
				flag=false;
		}
		if(flag==true)
			vertBinged++;
	}
	return vertBinged;
}

function isHorzBing(arr) {
	var horzBinged=0;
	
	for(var i=0; i<25 ; i+=5)
	{
		var flag = true;
		for(var j = i ; j<i+5 ; j++)
		{
			if(arr[j]==0)
				flag=false;
		}
		if(flag==true)
			horzBinged++;
	}
	return horzBinged;
}

function isDiagBing(arr) {
	var diag1=0;
	var diag2=0;
	var d1flag = true;
	var d2flag = true;

	for (var i = 0; i < 25; i+=6) {
		if(arr[i]==0)
				d1flag=false;
	}
	if(d1flag==true)
			diag1++;


	for (var i = 4; i <= 20; i+=4) {
		if(arr[i]==0)
				d2flag=false;
	}
	if(d2flag==true)
			diag2++;

	return diag1+diag2;

}

function isBing(arr)
{
	var bings = isVertBing(arr)+isHorzBing(arr)+isDiagBing(arr);
	var bind=false;

	if(bings>=5)
		bind=true
	var arr = {bind,bings};

	return arr;
}









