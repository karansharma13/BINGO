<?php 
session_start();
include 'connectDB.php';

$gameid = $_POST["game"];

if(isset($_POST["turn"]))
$turn = $_POST["turn"];

if(isset($_POST["player"]))
$player1 = $_POST["player"];

if(isset($_POST["getmove"]))
{
	$getMove=$_POST["getmove"];

	$gres = $conn->query("select * from game where gameid='$gameid'");
	$grow=$gres->fetch_object();

	if(isset($player1))
	{
		if($_SESSION["uid"]!=$player1)
		{
			$arr = array($grow->last_move,$grow->turn,$grow->p1status);
		}
		else
		{
			$arr = array($grow->last_move,$grow->turn,$grow->p2status);
		}

	}
	else
	{
		$arr = array($grow->last_move,$grow->turn);	
	}
	echo json_encode($arr);	
}

if(isset($_POST["postmove"]))
{
	$postMove=$_POST["postmove"];
	$pres= $conn->query("update game set last_move='$postMove',turn='$turn' where gameid='$gameid'");
}

$conn->close();

 ?>