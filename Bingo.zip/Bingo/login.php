<?php 

	session_start();
	include 'connectDB.php';
	date_default_timezone_set("Asia/Calcutta"); 


	if(isset($_POST['submit']))
	{
		$email=$_POST['email'];
		$pass=$_POST['pass'];
		if(isset($email) && isset($pass))
		{
			$pass=md5($pass);
			$res=$conn->query("select * from user where uemail='$email' and upassword='$pass'");
			if($res->num_rows>0)
			{
				$row=$res->fetch_object();
				$_SESSION["uid"]=$row->uid;
				$_SESSION["name"]=$row->ufname;
				$date = date( 'Y-m-d H:i:s');
				$act=$conn->query("update user set last_act = '$date', is_available='1' where uid = '$row->uid'");
				if($act)
				{
					header("location:players.php?player1=$row->uid");
				}
				else{
					echo "error ocuured!";
				}
			}
			else{
				echo "<script type='text/javascript'>alert('Incorrect email or password')</script>";
			}
		}
	}
	$conn->close();
?>
<!DOCTYPE html>

<html>
<head>
	<title>Bingo_Login</title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Radio+Canada&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/login_css.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<!-- <center> -->
	<div class="container">
		<div class="form">
		<h2>Login</h2>
		<form method="post">
			<div class="datas">
				<label class="label" for="email">Email:</label>
				<input type="text" name="email" placeholder="Enter email" id="email">
			</div>
			<div class="datas">
				<label class="label" for="pass">Password:</label>
				<input type="password" name="pass" placeholder="Enter password" id="pass">
			</div>
			<div class="datas">
				<input type="submit" name="submit" value="Login">
			</div>
		</form>
		</div>
	</div>
<!-- </center> -->

</body>
</html>