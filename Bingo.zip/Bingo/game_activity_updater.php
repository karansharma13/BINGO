<?php 

	session_start();
	include 'connectDB.php';

	$id = $_SESSION["uid"];
	$player1 = $_POST["player"];
	$gameid = $_POST["game"];

	date_default_timezone_set("Asia/Calcutta"); 

	$date = date( 'Y-m-d H:i:s');
	$res =$conn->query("update user set last_act='$date', is_available='0' where uid = '$id'"); 
	$res =$conn->query("update game set last_act_game='$date' where gameid = '$gameid'"); 
	// $diff = strtotime($date) - strtotime($check);

	if($_SESSION["uid"]!=$player1)
	{
		$q="update game set p2act='$date' where gid = '$gameid'";
		$res =$conn->query("update game set p2act='$date' where gameid = '$gameid'");

		$acres=$conn->query("select p1act from game where gameid = '$gameid'");
		$acrow=$acres->fetch_object();
		$check=$acrow->p1act;

		$diff = strtotime($date) - strtotime($check);
		if($diff>60)
		{
			$sres =$conn->query("update game set p1status='left' where gameid = '$gameid'");
			echo "left";
		}
	}
	else
	{
		$q="update game set p1act='$date' where gid = '$gameid'";
		$res =$conn->query("update game set p1act='$date' where gameid = '$gameid'");

		$acres=$conn->query("select p2act from game where gameid = '$gameid'");
		$acrow=$acres->fetch_object();
		$check=$acrow->p2act;

		$diff = strtotime($date) - strtotime($check);
		if($diff>60)
		{
			$sres =$conn->query("update game set p1status='left' where gameid = '$gameid'");
			echo "left";
		}
	}

	 $conn->close();
 ?>