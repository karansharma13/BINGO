<?php 
session_start();
include 'connectDB.php';

$p2=$_SESSION["uid"];
$res=$conn->query("select * from matches where p2='$p2'");
$output="<table>";
if($res->num_rows>0)
{
	while($row=$res->fetch_object())
	{
		$playres=$conn->query("select * from user where uid='$row->p1'");
		$playrow=$playres->fetch_object();

		$output .= "<tr><td class=\"players\"><u>$playrow->ufname $playrow->ulname</u> wants to play</td><td><a href=\" ";
		$output.="match_request_cleanup.php?player1=$row->p1&game=1";
		$output.="\" class=\"cplay\">Play</a><a class=\"cancel\" href=\"match_request_cleanup.php?player1=$row->p1&player2=$p2&cancel=1\">Cancel</a></td></tr>";

	}
		echo $output."</table>";
}
else 
	echo "no_player";


$conn->close();

 ?>