<?php 
session_start();
include 'connectDB.php';

$id = $_SESSION["uid"];

$q="select * from game where player1id = '$id' ";

$res=$conn->query($q);

if($res->num_rows>0)
{
	$row=$res->fetch_object();
	$arr = array($row->gameid,$id,$row->player2id);
	echo json_encode($arr);
}

$conn->close();
?>