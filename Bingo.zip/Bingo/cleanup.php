<?php 

include 'connectDB.php';
date_default_timezone_set("Asia/Calcutta"); 

	$acres=$conn->query("select * from user");
	while($acrow=$acres->fetch_object())
	{
		$check= $acrow->last_act;
		$date = date( 'Y-m-d H:i:s');
		$diff = strtotime($date)-strtotime($check);
		if($diff>60)
		{
			$q="update user set is_available='0' where uid = '$acrow->uid'";
			$res =$conn->query($q);

		}	
	}
	try{	
	$res=$conn->query("select * from game");
	}
	catch(Exception $e)
	{}
	while($row=$res->fetch_object())
	{
		$check= $row->last_act_game;
		$date = date( 'Y-m-d H:i:s');
		$diff = strtotime($date)-strtotime($check);
		if($diff>300)
		{
			$q="delete from game where gid = '$row->gid'";
			$res =$conn->query($q);

		}	
	};

$conn->close();

 ?>