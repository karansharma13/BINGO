<?php 

// return online players

include 'connectDB.php';
// include 'activity_checker.php';

session_start();

$id=$_SESSION['uid'];

$playres=$conn->query("select * from user");

$output="";

while($playrow=$playres->fetch_object())
{
	if($playrow->uid==$id)
		continue;

	$output = "<tr><td class=\"players\">$playrow->ufname $playrow->ulname</td><td><a href=\" ";

	if($playrow->is_available=="0")
		$output.="\" class=\"nAvail\"";
	else
		$output.="dummy_url?player1=$id&player2=$playrow->uid";

	$output.="\" class=\"play\">Play</a></td></tr>";

	echo $output;
}

$conn->close();

// <!-- **************************** User Last Activity checker*****************************************

//  date_default_timezone_set("Asia/Calcutta"); 
//  $acres=$conn->query("select * from user");
//  $acrow=$acres->fetch_object();
//  $check=$acrow->last_act;
//  $date = date( 'Y-m-d H:i:s');

//  $diff = strtotime($date) - strtotime($check);

// ************************************************************************************************* -->
?>

